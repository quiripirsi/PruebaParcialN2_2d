package larvaprueba.clientev3.service;

import larvaprueba.clientev3.model.Clientev3;
import larvaprueba.clientev3.repository.Clientev3Repository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
@Slf4j
public class Clientev3Service {

    @Autowired
    private Clientev3Repository cvr;

    public Clientev3 registrar(Clientev3 c){
        try {
            log.info("Guardando cliente...");
            return cvr.save(c);
        } catch (Exception e) {
            log.error("Error al guardar el cliente... {}", e.getMessage());
            throw new RuntimeException("No se ha podido guardar el cliente", e);
        }
    }

    public void eliminar(Clientev3 c){
        try {
            log.info("Eliminando cliente...");
            cvr.delete(c);
        } catch (Exception e) {
            log.error("Ha ocurrido un error al borrar al cliente... {}",e.getMessage());
            throw new RuntimeException("No se ha podido borrar al cliente", e);
        }
    }

    public List<Clientev3> listar(){
        try {
            log.info("Listando la clientela...");
            return cvr.findAll();
        } catch (Exception e) {
            log.error("Ha ocurrido un error listando la clientela... {}", e.getMessage());
            throw new RuntimeException("No se ha podido listar la clientela", e);
        }
    }
}
