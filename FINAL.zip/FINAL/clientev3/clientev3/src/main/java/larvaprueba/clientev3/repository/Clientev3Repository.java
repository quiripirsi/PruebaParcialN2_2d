package larvaprueba.clientev3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import larvaprueba.clientev3.model.Clientev3;

@Repository
public interface Clientev3Repository extends JpaRepository<Clientev3, Long>{
}
