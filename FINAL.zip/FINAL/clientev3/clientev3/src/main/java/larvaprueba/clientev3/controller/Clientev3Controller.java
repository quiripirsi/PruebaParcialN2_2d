package larvaprueba.clientev3.controller;

import larvaprueba.clientev3.Clientev3Application;
import larvaprueba.clientev3.model.Clientev3;
import larvaprueba.clientev3.service.Clientev3Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/cliente")
@Slf4j
public class Clientev3Controller {

    @Autowired
    private Clientev3Service cvs;

    @PostMapping
    public ResponseEntity<Clientev3> registrarCliente(@Valid @RequestBody Clientev3 cp){
        log.info("Registrando cliente via peticion");
        Clientev3 registrandoCliente = cvs.registrar(cp);
        return new ResponseEntity<>(registrandoCliente, HttpStatus.CREATED);

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCliente(@PathVariable Long id) {
        log.info("Eliminando cliente via peticion");
        Clientev3 eliminandoCliente = new Clientev3();
        eliminandoCliente.setId(id);
        cvs.eliminar(eliminandoCliente);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<Clientev3>> listandoClientes() {
        log.info("Listando los clientes via peticion");
        List<Clientev3> listaClientes = cvs.listar();
        return ResponseEntity.ok(listaClientes);

    }
}
