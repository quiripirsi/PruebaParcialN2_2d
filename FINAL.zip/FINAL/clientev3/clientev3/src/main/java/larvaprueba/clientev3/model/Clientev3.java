package larvaprueba.clientev3.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "clientes")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Clientev3 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 9, nullable = false)
    @NotBlank(message = "Tiene que tener un rut asignado")
    private String rut;

    @Column(nullable = false)
    @NotBlank(message = "Tiene que tener un nombre asignado")
    private String nombre;

    @Column(nullable = false)
    @NotBlank(message = "Tiene que tener un apellido asignado")
    private String apellido;

    @Column(length = 9, nullable = false)
    @NotBlank(message = "Tiene que tener un numero de telefono asignado")
    private String numtelefono;

}
