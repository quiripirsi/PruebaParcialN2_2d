package larvaprueba.productov3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Productov3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
