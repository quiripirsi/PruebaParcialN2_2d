package larvaprueba.productov3.controller;

import larvaprueba.productov3.Productov3Application;
import larvaprueba.productov3.model.Productov3;
import larvaprueba.productov3.service.Productov3Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/api/producto")
public class Productov3Controller {

    @Autowired
    private Productov3Service pvz;

    @PostMapping
    public ResponseEntity<Productov3> registrarProducto(@Valid @RequestBody Productov3 p){
        log.info("Registrando producto via peticion");
        Productov3 registrandoProducto = pvz.registrar(p);
        return new ResponseEntity<>(registrandoProducto, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarProducto(@PathVariable Long id) {
        log.info("Eliminando producto via peticion");
        Productov3 eliminandoProducto = new Productov3();
        eliminandoProducto.setId(id);
        pvz.eliminar(eliminandoProducto);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<Productov3>> listandoProducto() {
        log.info("Listando los productos via peticion");
        List<Productov3> listaProducto = pvz.listar();
        return ResponseEntity.ok(listaProducto);
    }
}
