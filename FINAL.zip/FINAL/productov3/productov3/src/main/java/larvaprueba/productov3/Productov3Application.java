package larvaprueba.productov3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Productov3Application {

	public static void main(String[] args) {
		SpringApplication.run(Productov3Application.class, args);
	}

}
