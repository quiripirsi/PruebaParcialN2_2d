package larvaprueba.productov3.service;

import larvaprueba.productov3.model.Productov3;
import larvaprueba.productov3.repository.Productov3Repository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
@Slf4j
public class Productov3Service {

    @Autowired
    private Productov3Repository pvr;

    public Productov3 registrar(Productov3 p){
        try {
            log.info("Guardando producto...");
            return pvr.save(p);
        } catch (Exception e) {
            log.error("Error al guardar el producto... {}", e.getMessage());
            throw new RuntimeException("No se ha podido guardar el producto correctamente", e);
        }
    }

    public void eliminar(Productov3 p){
        try {
            log.info("Eliminando producto...");
            pvr.delete(p);
        } catch (Exception e) {
            log.error("Ha ocurrido un error al borrar producto... {}",e.getMessage());
            throw new RuntimeException("No se ha podido borrar el producto correctamente", e);
        }
    }

    public List<Productov3> listar(){
        try {
            log.info("Listando productos...");
            return pvr.findAll();
        } catch (Exception e) {
            log.error("Ha ocurrido un error listando los productos... {}", e.getMessage());
            throw new RuntimeException("No se ha podido listar los productos correctamente", e);
        }
    }
}
