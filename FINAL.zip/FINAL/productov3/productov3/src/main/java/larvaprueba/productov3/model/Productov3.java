package larvaprueba.productov3.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "productos")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Productov3 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotBlank(message = "Tiene que tener un nombre asignado")
    private String nombre;

    @Column(nullable = false)
    @NotBlank(message = "Tiene que tener una categoria asignada")
    private String categoria;

    @Column(nullable = false)
    @NotNull(message = "Tiene que tener precio el producto")
    private Double precio;

}
