package larvaprueba.productov3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import larvaprueba.productov3.model.Productov3;

@Repository
public interface Productov3Repository extends JpaRepository<Productov3, Long> {
}
