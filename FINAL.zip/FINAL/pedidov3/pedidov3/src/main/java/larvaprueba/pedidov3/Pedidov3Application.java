package larvaprueba.pedidov3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pedidov3Application {

	public static void main(String[] args) {
		SpringApplication.run(Pedidov3Application.class, args);
	}

}
