package larvaprueba.pedidov3.service;

import larvaprueba.pedidov3.model.Pedidov3;
import larvaprueba.pedidov3.repository.Pedidov3Repository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import org.springframework.web.client.RestClient;

@Service
@Slf4j
public class Pedidov3Service {

    @Autowired
    private Pedidov3Repository pevr;

    @Autowired
    private RestClient rc;

    public Pedidov3 crearPedido(Pedidov3 pev3) {
        try {
            log.info("Hay que validar al cliente");
            rc.get().uri("http://localhost:8080/api/cliente/" + pev3.getClienteId()).retrieve().toBodilessEntity();
            rc.put().uri("http://localhost:8083/api/inventario/descontar/" + pev3.getProductoId() + "/" + pev3.getCantidad()).retrieve().toBodilessEntity();
            pev3.setEstadoPedido("PROCESADO");
            log.info("Pedido creado exitossamente");
            return pevr.save(pev3);
        } catch (Exception e) {
            log.error("No se ha podido crear el pedido {}", e.getMessage());
            throw new RuntimeException("Error al crear el pedido " + e.getMessage());
        }
    }
}

