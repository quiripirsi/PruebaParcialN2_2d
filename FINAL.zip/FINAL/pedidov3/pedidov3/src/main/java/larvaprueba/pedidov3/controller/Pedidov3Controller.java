package larvaprueba.pedidov3.controller;

import jakarta.validation.Valid;
import larvaprueba.pedidov3.model.Pedidov3;
import larvaprueba.pedidov3.service.Pedidov3Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
@Slf4j
public class Pedidov3Controller {

    @Autowired
    private Pedidov3Service pvs;

    @PostMapping
    public ResponseEntity<Pedidov3> guardarPedido(@Valid @RequestBody Pedidov3 pev3) {
        log.info("Creando nuevo pedido via peticion");
        Pedidov3 pv3 = pvs.crearPedido(pev3);
        return new ResponseEntity<>(pv3, HttpStatus.CREATED);
    }
}