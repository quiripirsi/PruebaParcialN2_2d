package larvaprueba.pedidov3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import larvaprueba.pedidov3.model.Pedidov3;

@Repository
public interface Pedidov3Repository extends JpaRepository<Pedidov3, Long> {
}
