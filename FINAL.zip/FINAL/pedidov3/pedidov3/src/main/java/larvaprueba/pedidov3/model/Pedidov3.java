package larvaprueba.pedidov3.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "pedidos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pedidov3 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotNull(message = "Necesita el id del cliente")
    private Long clienteId;

    @Column(nullable = false)
    @NotNull(message = "Necesita el id del producto")
    private Long productoId;

    @Column(nullable = false)
    @Min(value = 1, message = "Tiene que tener una cantidad minima")
    private Integer cantidad;

    @Column(nullable = false)
    private String estadoPedido;

}