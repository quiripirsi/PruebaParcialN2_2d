package larvaprueba.inventariov3.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "inventario")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Inventariov3 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotBlank(message = "Tiene que estar con nombre")
    private String nombreProducto;

    @Column(nullable = false)
    @NotNull(message = "Tiene que tener una cantidad el producto")
    private Integer stock;

}
