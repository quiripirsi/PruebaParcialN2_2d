package larvaprueba.inventariov3.service;

import larvaprueba.inventariov3.model.Inventariov3;
import larvaprueba.inventariov3.repository.Inventariov3Repository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
@Slf4j
public class Inventariov3Service {

    @Autowired
    private Inventariov3Repository ivr;

    public Inventariov3 registrarstock(Inventariov3 stock) {
        try {
            log.info("Añadiendo stock para el producto: {}", stock.getNombreProducto());
            return ivr.save(stock);
        } catch (Exception e) {
            log.error("Error al registrar inventario: {}", e.getMessage());
            throw new RuntimeException("Error al guardar stock", e);
        }
    }

    public Inventariov3 restarstock(Long id, Integer stock) {
        try {
            log.info("Descontando del inventario");
            Inventariov3 ario = ivr.findById(id).orElseThrow(() -> new RuntimeException("Producto no encontrado"));
            if (ario.getStock() < stock) {
                log.warn("Stock insuficiente");
                throw new RuntimeException("No hay stock para el producto");
            }
            ario.setStock(ario.getStock() - stock);
            return ivr.save(ario);
        } catch (Exception e) {
            log.error("Error descontar el stock {}", e.getMessage());
            throw new RuntimeException("Error al descontar stock " + e.getMessage());
        }
    }
}
