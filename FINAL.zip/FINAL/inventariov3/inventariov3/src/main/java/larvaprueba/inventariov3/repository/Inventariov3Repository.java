package larvaprueba.inventariov3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import larvaprueba.inventariov3.model.Inventariov3;

@Repository
public interface Inventariov3Repository extends JpaRepository<Inventariov3, Long> {
}
