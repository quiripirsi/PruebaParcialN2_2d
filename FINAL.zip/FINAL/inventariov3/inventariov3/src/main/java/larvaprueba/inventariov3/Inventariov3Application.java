package larvaprueba.inventariov3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Inventariov3Application {

	public static void main(String[] args) {
		SpringApplication.run(Inventariov3Application.class, args);
	}

}
