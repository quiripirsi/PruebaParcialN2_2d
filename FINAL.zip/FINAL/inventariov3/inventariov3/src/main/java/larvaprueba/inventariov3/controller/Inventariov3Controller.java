package larvaprueba.inventariov3.controller;

import larvaprueba.inventariov3.Inventariov3Application;
import larvaprueba.inventariov3.model.Inventariov3;
import larvaprueba.inventariov3.service.Inventariov3Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/api/inventario")
public class Inventariov3Controller {

    @Autowired
    private Inventariov3Service ivs;

    @PostMapping
    public ResponseEntity<Inventariov3> registrarInventario(@Valid @RequestBody Inventariov3 iv3) {
        log.info("Registrando inventario via peticion");
        return new ResponseEntity<>(ivs.registrarstock(iv3), HttpStatus.CREATED);
    }

    @PutMapping("/descontar/{nombreProducto}/{stock}")
    public ResponseEntity<Inventariov3> descontarStock(@PathVariable Long id, @PathVariable Integer stock) {
        log.info("Descontando stock del inventario via peticion");
        return ResponseEntity.ok(ivs.restarstock(id, stock));
    }
}
