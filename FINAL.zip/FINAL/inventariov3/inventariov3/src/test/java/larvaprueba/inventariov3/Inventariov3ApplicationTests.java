package larvaprueba.inventariov3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Inventariov3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
