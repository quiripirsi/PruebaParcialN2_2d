package com.example.PruebaParcialN2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaParcialN2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
