package com.example.PruebaParcialN2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaParcialN2Application {

	public static void main(String[] args) {
		SpringApplication.run(PruebaParcialN2Application.class, args);
	}

}
